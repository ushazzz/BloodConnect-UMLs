import java.time.LocalDate;

public class Donor extends User {
    private String donorId;
    private String bloodGroup;
    private LocalDate dob;
    private String medicalHistory;
    private EligibilityStatus eligibilityStatus;
    private LocalDate lastDonationDate;

    public enum EligibilityStatus { PENDING, APPROVED, REJECTED, DEFERRED }

    public Donor(String id, String name, String email, String phone, String donorId,
                 String bloodGroup, LocalDate dob, String medicalHistory) {
        super(id, name, email, phone, "DONOR");
        this.donorId = donorId;
        this.bloodGroup = bloodGroup;
        this.dob = dob;
        this.medicalHistory = medicalHistory;
        this.eligibilityStatus = EligibilityStatus.PENDING;
    }

    // getters & setters
    public String getDonorId(){ return donorId; }
    public String getBloodGroup(){ return bloodGroup; }
    public LocalDate getDob(){ return dob; }
    public String getMedicalHistory(){ return medicalHistory; }
    public EligibilityStatus getEligibilityStatus(){ return eligibilityStatus; }
    public LocalDate getLastDonationDate(){ return lastDonationDate; }

    public void setEligibilityStatus(EligibilityStatus s){ this.eligibilityStatus = s; }
    public void setLastDonationDate(LocalDate d){ this.lastDonationDate = d; }

    @Override
    public String toString(){
        return "Donor[" + donorId + "," + name + "," + bloodGroup + "," + eligibilityStatus + "]";
    }
}
