// Donation.java
import java.time.LocalDateTime;

public class Donation {
    public enum Status { SCHEDULED, COMPLETED, CANCELLED, QUARANTINED }
    private String donationId;
    private String donorId;
    private LocalDateTime dateTime;
    private String bloodUnitId;
    private Status status;
    private int volumeMl;
    private String testResults;

    public Donation(String donationId, String donorId, LocalDateTime dateTime, int volumeMl){
        this.donationId = donationId;
        this.donorId = donorId;
        this.dateTime = dateTime;
        this.volumeMl = volumeMl;
        this.status = Status.SCHEDULED;
    }

    // getters/setters
    public String getDonationId(){ return donationId; }
    public String getDonorId(){ return donorId; }
    public LocalDateTime getDateTime(){ return dateTime; }
    public String getBloodUnitId(){ return bloodUnitId; }
    public Status getStatus(){ return status; }
    public int getVolumeMl(){ return volumeMl; }
    public String getTestResults(){ return testResults; }

    public void setBloodUnitId(String id){ this.bloodUnitId = id; }
    public void setStatus(Status s){ this.status = s; }
    public void setTestResults(String results){ this.testResults = results; }

    @Override
    public String toString(){
        return "Donation[" + donationId + ", donor=" + donorId + ", status=" + status + "]";
    }
}
