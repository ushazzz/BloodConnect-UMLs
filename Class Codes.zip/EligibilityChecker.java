// EligibilityChecker.java
import java.time.LocalDate;
import java.time.Period;

public class EligibilityChecker {
    // very simple rules: age between 18 and 65, last donation >= 90 days
    public static class Result {
        public final boolean eligible;
        public final String reason;
        public Result(boolean e, String r){ this.eligible = e; this.reason = r; }
    }

    public Result check(Donor d) {
        if (d == null) return new Result(false, "Donor record not found");
        LocalDate dob = d.getDob();
        int age = Period.between(dob, LocalDate.now()).getYears();
        if (age < 18 || age > 65) return new Result(false, "Age not in permitted range: " + age);
        if (d.getLastDonationDate() != null) {
            long days = java.time.temporal.ChronoUnit.DAYS.between(d.getLastDonationDate(), LocalDate.now());
            if (days < 90) return new Result(false, "Too recent donation: " + days + " days ago");
        }
        // add more checks e.g. medical history
        return new Result(true, "Eligible");
    }
}
