// BloodUnit.java
import java.time.LocalDate;

public class BloodUnit {
    public enum Status { AVAILABLE, RESERVED, ISSUED, QUARANTINED, EXPIRED }
    private String unitId;
    private String bloodGroup;
    private String componentType;
    private LocalDate collectedDate;
    private LocalDate expiryDate;
    private String storageLocation;
    private Status status;

    public BloodUnit(String unitId, String bloodGroup, String componentType, LocalDate collectedDate, LocalDate expiryDate, String storageLocation){
        this.unitId = unitId;
        this.bloodGroup = bloodGroup;
        this.componentType = componentType;
        this.collectedDate = collectedDate;
        this.expiryDate = expiryDate;
        this.storageLocation = storageLocation;
        this.status = Status.AVAILABLE;
    }

    // getters/setters
    public String getUnitId(){ return unitId; }
    public String getBloodGroup(){ return bloodGroup; }
    public String getComponentType(){ return componentType; }
    public LocalDate getCollectedDate(){ return collectedDate; }
    public LocalDate getExpiryDate(){ return expiryDate; }
    public String getStorageLocation(){ return storageLocation; }
    public Status getStatus(){ return status; }
    public void setStatus(Status s){ this.status = s; }

    @Override
    public String toString(){ return "BloodUnit[" + unitId + "," + bloodGroup + "," + status + "]"; }
}
