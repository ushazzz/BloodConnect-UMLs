// Staff.java
public class Staff extends User {
    private String staffId;
    private String department;

    public Staff(String id, String name, String email, String phone, String staffId, String department, String role){
        super(id, name, email, phone, role);
        this.staffId = staffId;
        this.department = department;
    }

    public String getStaffId(){ return staffId; }
    public String getDepartment(){ return department; }
}
