// RegistrationService.java
import java.util.HashMap;
import java.util.Map;

public class RegistrationService {
    private Map<String, Donor> donors = new HashMap<>();
    private EligibilityChecker checker = new EligibilityChecker();
    private NotificationService notifications;

    public RegistrationService(NotificationService notifications){
        this.notifications = notifications;
    }

    public Donor registerDonor(Donor d){
        donors.put(d.getDonorId(), d);
        // initial check
        EligibilityChecker.Result r = checker.check(d);
        if (!r.eligible) {
            d.setEligibilityStatus(Donor.EligibilityStatus.DEFERRED);
            notifications.send("notif-" + d.getDonorId(), d.getId(), "REGISTRATION", "Registration deferred: " + r.reason);
        } else {
            d.setEligibilityStatus(Donor.EligibilityStatus.PENDING);
            notifications.send("notif-" + d.getDonorId(), d.getId(), "REGISTRATION", "Registration received, pending approval.");
        }
        return d;
    }

    public boolean approveDonor(String donorId, String approverId){
        Donor d = donors.get(donorId);
        if (d == null) return false;
        d.setEligibilityStatus(Donor.EligibilityStatus.APPROVED);
        notifications.send("notif-" + donorId, d.getId(), "REGISTRATION", "Your registration has been approved.");
        return true;
    }

    public boolean rejectDonor(String donorId, String reason){
        Donor d = donors.get(donorId);
        if (d == null) return false;
        d.setEligibilityStatus(Donor.EligibilityStatus.REJECTED);
        notifications.send("notif-" + donorId, d.getId(), "REGISTRATION", "Your registration was rejected: " + reason);
        return true;
    }

    public Donor updateDonor(Donor d){
        donors.put(d.getDonorId(), d);
        notifications.send("notif-update-" + d.getDonorId(), d.getId(), "PROFILE", "Your profile has been updated.");
        return d;
    }

    public Donor findDonor(String donorId){
        return donors.get(donorId);
    }
}
