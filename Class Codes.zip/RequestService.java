// RequestService.java
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

public class RequestService {
    private InventoryService inventory;
    private NotificationService notifications;

    public RequestService(InventoryService inventory, NotificationService notifications){
        this.inventory = inventory;
        this.notifications = notifications;
    }

    public Request createRequest(String recipientId, String bloodGroup, int units, String priority){
        String reqId = "R-" + UUID.randomUUID().toString().substring(0,8);
        Request r = new Request(reqId, recipientId, bloodGroup, units, priority);
        List<BloodUnit> matched = inventory.findAvailableByGroup(bloodGroup, units);
        if (matched.size() >= units){
            List<String> ids = matched.stream().map(BloodUnit::getUnitId).collect(Collectors.toList());
            boolean reserved = inventory.reserveUnits(ids);
            if (reserved){
                r.setStatus(Request.Status.ALLOCATED);
                notifications.send("req-"+reqId, recipientId, "REQUEST", "Your request has been allocated. Units: "+ids);
            } else {
                notifications.send("req-"+reqId, recipientId, "REQUEST", "Unable to reserve units at this time.");
            }
        } else {
            notifications.send("req-"+reqId, recipientId, "REQUEST", "Insufficient units. Triggering emergency notification.");
            // in real system: broadcast emergency
        }
        return r;
    }
}
