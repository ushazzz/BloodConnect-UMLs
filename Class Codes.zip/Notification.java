// Notification.java
import java.time.LocalDateTime;

public class Notification {
    private String notificationId;
    private String userId;
    private String type;
    private String message;
    private LocalDateTime sentAt;
    private boolean read;

    public Notification(String notificationId, String userId, String type, String message){
        this.notificationId = notificationId;
        this.userId = userId;
        this.type = type;
        this.message = message;
        this.sentAt = LocalDateTime.now();
        this.read = false;
    }

    // getters/setters
    public String getNotificationId(){ return notificationId; }
    public String getUserId(){ return userId; }
    public String getType(){ return type; }
    public String getMessage(){ return message; }
    public LocalDateTime getSentAt(){ return sentAt; }
    public boolean isRead(){ return read; }
    public void markRead(){ this.read = true; }
}
