// Request.java
import java.time.LocalDateTime;

public class Request {
    public enum Status { OPEN, ALLOCATED, FULFILLED, CANCELLED }
    private String requestId;
    private String recipientId;
    private String bloodGroup;
    private int unitsRequested;
    private Status status;
    private LocalDateTime createdAt;
    private String priority;

    public Request(String requestId, String recipientId, String bloodGroup, int unitsRequested, String priority){
        this.requestId = requestId;
        this.recipientId = recipientId;
        this.bloodGroup = bloodGroup;
        this.unitsRequested = unitsRequested;
        this.status = Status.OPEN;
        this.createdAt = LocalDateTime.now();
        this.priority = priority;
    }

    // getters/setters
    public String getRequestId(){ return requestId; }
    public String getRecipientId(){ return recipientId; }
    public String getBloodGroup(){ return bloodGroup; }
    public int getUnitsRequested(){ return unitsRequested; }
    public Status getStatus(){ return status; }
    public void setStatus(Status s){ this.status = s; }
}
