// Recipient.java
public class Recipient extends User {
    private String recipientId;
    private String hospitalName;

    public Recipient(String id, String name, String email, String phone, String recipientId, String hospitalName){
        super(id, name, email, phone, "RECIPIENT");
        this.recipientId = recipientId;
        this.hospitalName = hospitalName;
    }

    public String getRecipientId(){ return recipientId; }
    public String getHospitalName(){ return hospitalName; }
}
