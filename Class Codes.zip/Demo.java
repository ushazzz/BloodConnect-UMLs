public class Demo {
    public static void main(String[] args) {
        NotificationService ns = new NotificationService();
        InventoryService inv = new InventoryService();
        RegistrationService reg = new RegistrationService(ns);
        DonationService donSvc = new DonationService(inv, ns);
        RequestService reqSvc = new RequestService(inv, ns);

        Donor d = new Donor("u1","Ali Khan","ali@example.com","0312xxx","donor-001","A+", java.time.LocalDate.of(1990,1,1), "None");
        reg.registerDonor(d);
        reg.approveDonor("donor-001","manager-01");
        Donation donation = donSvc.performDonation(d, 450);

        Request req = reqSvc.createRequest("recipient-01", "A+", 1, "HIGH");
    }
}
