// InventoryService.java
import java.time.LocalDate;
import java.util.*;
import java.util.stream.Collectors;

public class InventoryService {
    private Map<String, BloodUnit> units = new HashMap<>();

    public void addUnit(BloodUnit unit){
        units.put(unit.getUnitId(), unit);
    }

    public List<BloodUnit> findAvailableByGroup(String bloodGroup, int count){
        List<BloodUnit> candidates = units.values().stream()
            .filter(u -> u.getBloodGroup().equalsIgnoreCase(bloodGroup))
            .filter(u -> u.getStatus() == BloodUnit.Status.AVAILABLE)
            .filter(u -> u.getExpiryDate().isAfter(LocalDate.now()))
            .sorted(Comparator.comparing(BloodUnit::getCollectedDate))
            .collect(Collectors.toList());
        return candidates.stream().limit(count).collect(Collectors.toList());
    }

    public boolean reserveUnits(List<String> unitIds){
        for(String id: unitIds){
            BloodUnit u = units.get(id);
            if (u == null || u.getStatus() != BloodUnit.Status.AVAILABLE) return false;
        }
        for(String id: unitIds){
            units.get(id).setStatus(BloodUnit.Status.RESERVED);
        }
        return true;
    }

    public void issueUnit(String unitId){
        BloodUnit u = units.get(unitId);
        if (u != null) u.setStatus(BloodUnit.Status.ISSUED);
    }

    public void cleanupExpired(){
        LocalDate now = LocalDate.now();
        for(BloodUnit u : units.values()){
            if (u.getExpiryDate().isBefore(now) && u.getStatus() != BloodUnit.Status.EXPIRED){
                u.setStatus(BloodUnit.Status.EXPIRED);
            }
        }
    }
}
