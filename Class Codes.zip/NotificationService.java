// NotificationService.java
import java.util.ArrayList;
import java.util.List;

public class NotificationService {
    private List<Notification> inbox = new ArrayList<>();

    public Notification send(String notificationId, String userId, String type, String message) {
        Notification n = new Notification(notificationId, userId, type, message);
        inbox.add(n);
        // in a real system we'd push email/SMS/push; here we just store
        System.out.println("Notification sent to " + userId + ": " + message);
        return n;
    }

    public List<Notification> getNotificationsFor(String userId){
        List<Notification> out = new ArrayList<>();
        for (Notification n : inbox) if (n.getUserId().equals(userId)) out.add(n);
        return out;
    }
}
