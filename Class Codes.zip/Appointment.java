// Appointment.java
import java.time.LocalDateTime;

public class Appointment {
    public enum Status { SCHEDULED, COMPLETED, CANCELLED }
    private String appointmentId;
    private String donorId;
    private LocalDateTime scheduledDateTime;
    private Status status;

    public Appointment(String appointmentId, String donorId, LocalDateTime scheduledDateTime){
        this.appointmentId = appointmentId;
        this.donorId = donorId;
        this.scheduledDateTime = scheduledDateTime;
        this.status = Status.SCHEDULED;
    }

    // getters/setters
    public String getAppointmentId(){ return appointmentId; }
    public String getDonorId(){ return donorId; }
    public LocalDateTime getScheduledDateTime(){ return scheduledDateTime; }
    public Status getStatus(){ return status; }
    public void setStatus(Status s){ this.status = s; }
}
