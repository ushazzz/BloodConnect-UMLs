// DonationService.java
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.UUID;

public class DonationService {
    private InventoryService inventory;
    private NotificationService notifications;

    public DonationService(InventoryService inventory, NotificationService notifications){
        this.inventory = inventory;
        this.notifications = notifications;
    }

    public Donation performDonation(Donor donor, int volumeMl) {
        String donationId = "D-" + UUID.randomUUID().toString().substring(0,8);
        Donation donation = new Donation(donationId, donor.getDonorId(), LocalDateTime.now(), volumeMl);
        // create a BloodUnit
        String unitId = "U-" + UUID.randomUUID().toString().substring(0,8);
        LocalDate collectedDate = LocalDate.now();
        LocalDate expiry = collectedDate.plusDays(42); // example shelf-life
        BloodUnit unit = new BloodUnit(unitId, donor.getBloodGroup(), "WHOLE", collectedDate, expiry, "Fridge-1");
        // assume tests pending -- but for demo mark available
        inventory.addUnit(unit);
        donation.setBloodUnitId(unitId);
        donation.setStatus(Donation.Status.COMPLETED);
        donor.setLastDonationDate(LocalDate.now());
        notifications.send("don-" + donationId, donor.getId(), "DONATION", "Thank you for donating. Donation id: " + donationId);
        return donation;
    }
}
